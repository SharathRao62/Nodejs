import React from 'react'
import Greet from './Greet'
import Parent from './Parent'

function App() {
    const greeMessage = "Hello Good Evening"
    return (
        <div>
            {/* <Greet greet={greeMessage} message="Some Message" /> */}
            { }<Parent />
        </div>
    )
}

export default App




//exapmple 3
//Greet
//Welcome Sharath Rao aka Iron Name

// function App() {
//     const name = "Sharath Rao"
//     return (
//         <div>
//             <Greet name={name} heroName="a.k.a Iron Man" />
//         </div>
//     )
// }

// export default App



