import React, { Component } from 'react'
import Child from './Child'

export class Parent extends Component {

    render() {
        const user = {
            firstName: "Sharath",
            lastName: "Rao",
            address: "Sullia"
        }

        return (
            <div>
                <Child {...user}>  //spread operator //

                    {/* <Child>  */}
                    <h3>This Message Projected  </h3>
                    <h4>This is Another Message</h4>
                </Child>
            </div>
        )
    }
    //end of render
}

export default Parent