// import React from 'react'

// function Greet({greet,message}) {
//     console.log();

//   return (
//     <div>
//       <h1>{greet}Guys...</h1>
//       <h2>{message}</h2>
//     </div>
//   )
// }

// export default Greet




// import React, { Component } from 'react'

// export class App extends Component {

//     //props
//     render() {
//         //object destructuring
//        let  {greet,message}=this.props;

//         return (
//             <div>
//                 <h1>{greet}</h1>
//                 <h2>{message}</h2>
//             </div>
//         )
//     }
// }

// export default App




//example 3

import React, { Component } from 'react'

export class App extends Component {

    //props
    render() {
        //object destructuring
        let { name, heroName } = this.props;

        return (
            <div>
                <h1>{name}</h1>
                <h2>{heroName}</h2>
            </div>
        )
    }
}

export default App