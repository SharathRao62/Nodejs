import React, { Component } from 'react'

export class Message extends Component {

    constructor() {
        super();
        this.state = {
            message: "Welcome Visitor..."
        }
        this.changeMessage = this.changeMessage.bind(this);
    }
    changeMessage() {
        console.log('Clicked...');
        // this.state.message ="Thank you for Subscribing..."
        console.log(this);
        this.setState({
            message: 'Thank you for Subscribing...'
        })
    }



    // render() {
    //     return (
    //         <div>
    //             <h2>{this.state.message}</h2>
    //             <button onClick={this.changeMessage}>Subscribe</button>
    //         </div>
    //     )
    // }


    changeMessage2(event) {
        console.log(event);
        this.setState({
            message: `Thank you for Subscribing...`
        });
    }


    render() {
        // const param = 20;
        return (
            <div>
                <h2>{this.state.message}</h2>
                <button
                    onClick={(e) => this.changeMessage2(e)}>
                    Subscribe
                </button>
            </div>
        )
    }

}

export default Message
