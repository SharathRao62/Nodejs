import React from 'react'
// import Message from './Message'
import Counter from './Counter'

function App() {
    return (
        <div>
            {/* <Message /> */}
  
  <Counter/>
        </div>
    )
}

export default App
