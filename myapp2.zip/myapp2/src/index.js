import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './states in react/App';
// import App from './simple props demo/App';




const root = createRoot(document.getElementById("root"))
// root.render(<App />);
root.render(<App />);


export default App; //if we want declare outside the module we can use export default