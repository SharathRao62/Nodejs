let user = "Sharath";
let sirName = " Rao"
let greet = `Welcome 'single quotes "double quotes"
    ${user.concat(sirName)} to ES6
    this is third line
    this is fourth line`;

console.log(greet);

let id =1;
let name= 'dqadasdasasdadadddad'
let url = `http://localhost:3000/users/${id}/${name}`;

console.log(url);
