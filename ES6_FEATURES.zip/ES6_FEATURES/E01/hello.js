let a= 'sharath';
let b= 'rao'

console.log(`${a} ${b}`);