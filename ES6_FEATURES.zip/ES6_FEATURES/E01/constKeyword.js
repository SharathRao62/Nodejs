const obj1 = {
    name:'Sharath'
}
obj1.name = 'Rao';
// obj1 ={};   //Error
console.log(obj1.name);


//Diference between let vs const

let obj2 ={
    name:'sharath',
    place:'sullia',
    city:'bangalore',
    address:'kudkuli'
}
console.log(obj2);

