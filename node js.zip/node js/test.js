let currentNumber = 20250200;

function registrationNumber() {
    return ++currentNumber;
}

console.log(registrationNumber());

console.log(Math.floor(Math.random() * 10));
