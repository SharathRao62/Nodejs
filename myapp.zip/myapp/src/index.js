//react pacakge is from react lib
//react dom is from DOM library

import React from 'react';
import { createRoot } from 'react-dom/client';
import  ClassBasedComp from './single components demos/classBasedComp'
import  FunctionalComp from './single components demos/functionalComp'
import JSXDemos from './jsx demos/JSXDemos';

//Parent Component
function App() {


    // JSX
    return (
        <div>
            <h1>Hello World!!!</h1>
            <h2>Hello World!!!</h2>
            <p>Hello this is my first page</p>
            <FunctionalComp />
            <ClassBasedComp />
            <JSXDemos/>
        </div>
    );
}

const root = createRoot(document.getElementById("root"))
root.render(<App />);

export default App; //if we want declare outside the module we can use export default