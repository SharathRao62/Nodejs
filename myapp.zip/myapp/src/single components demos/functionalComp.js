import React from "react";

function FunctionalComp() {
    return <h2> This is inside the Functional Component</h2>
}

export default FunctionalComp;
