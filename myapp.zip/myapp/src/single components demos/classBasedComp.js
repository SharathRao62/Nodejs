import React, { Component } from "react";

// Class Based Component
class ClassBasedComp extends Component {
    render() {
        return <h2>Inside the Class Based Component</h2>;
    }
}

export default ClassBasedComp;