import React from 'react'
import '../jsx demos/JSXPages.css';
function buttonTextFunction() {
    return 'Click Here'
}

const buttonText = 'Submit'
function JSXDemos() {
    return (
        <div style={{ border: "2px solid red" }}>
            <label className="label">Enter Name : </label>
            <input type="text" id="name" />
            <button style={{ backgroundColor: 'blue', color: 'white' }}>
                {"Please " + buttonTextFunction()}</button>
        </div >
    )
}

export default JSXDemos
