
const { v4: uuidv4 } = require("uuid");

// Every microservice shall create a unique UUID
const orderID = uuidv4();
console.log(`Generated Order ID: ${orderID}`);